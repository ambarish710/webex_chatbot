***************--------------------------------------------------------------------------------***************
                                    Webex Notifier & ChatBot Utility
***************--------------------------------------------------------------------------------***************



General Information --
    This utility provides the following features --
        1. Periodic Notifier Feature --
            - Runs the given fixed jira query provided in information.yaml (jira_details:fixed_jira_query)
            - Collects the list of bugs associated with the Jira query
            - Sends the formatted list of bugs to the given Webex Teams Group provided in information.yaml after
              the specified time interval

        2. ChatBot Feature --
            - Monitors the given Webex Teams Group [provided in information.yaml (webex_teams_details:webex_room_id)]
            - Reads the user input, checks if its a valid keyword and responds accordingly,
                - If the user input is "Adding New Keyword",
                    - Adds a new keyword along with the respective query to the keyword_query_mappings.yaml
                - If the user input is "Deleting Existing Keyword",
                    - Deletes existing keyword from the keyword_query_mappings.yaml
                - If there is a JIRA query associated with the keyword,
                    - Collects the list of bugs associated with the JIRA query
                    - Sends the formatted list of bugs to the Webex Teams Group along with the bug count
                - If the user input is "help" keyword,
                    - Collects the list of all the keywords present
                    - Sends the formatted list of all the keywords to the Webex Teams Group
                - If the user input is "Get Testing Status" for a given build,
                    - Collects the overall testing status of the build from QDNA server
                    - Sends the regression status report to the  Webex Teams Group
                - If the user input is "Get Detailed Testing Status" for a given build,
                    - Collects the detailed testing status from QDNA server for all the jobs ran against the build
                    - Sends the detailed regression status report to the  Webex Teams Group
                - If the user input is "Get Bug Details" for a given bug,
                    - Collects bug details from JIRA server
                    - Sends the bug detail report to the  Webex Teams Group
            - Stores the last served request timestamp in "tmp/metadata.yaml" (Readonly)



Usage --
    - To track incoming/existing bugs for a given release periodically
    - To check build regression status



Setup and Installation --
    1. Create a virtual environment and run the following command (preferably with python 2.7), to install all the
       dependency packages required by "Webex Teams Notifier Utility"
            --  "pip install -r requirements.txt"


    2. Update information.yaml with details about Jira Server, CDET Server, Webex Teams Group, & QDNA server details --
            general_details:
                chat_bot_read_time_interval: 5                              # Time interval in between 2 consecutive read checks
                periodic_notifier_interval: 6                               # Future Paramter for scheduling periodic bug notifier (Cronjob input)

            jira_details:
                jira_user: "JIRA_USERNAME"                                  #base64encoded
                jira_password: "JIRA_PASSWORD"
                jira_server_url: "https://jira-eng-sjc1.cisco.com/jira/"    # Jira Backend URL [Hardcoded]
                fixed_jira_query: "FIXED_JIRA_QUERY"                        # Fixed Jira query used by periodic bug notifier
                string_header_with_response: "Here are the Bugs --\n"       # Example

            cdet_details:
                cdet_user: "CDET_USER"
                cdet_password: "CDET_PASSWORD"
                auth_token: "TOKEN"
                cdet_url: "CDET_BACKEND_URL"
                fixed_cdet_query: "CDET_QUERY"
                string_header_with_response: "TEXT"

            webex_teams_details:
                webex_url: "https://api.ciscospark.com/v1/messages"         # Webex Teams Backend URL [Hardcoded]
                webex_room_id: "WEBEX_ROOM_ID"
                # Webex Bot details
                auth_token: "TOKEN"                                         # Can be found here https://developer.webex.com/my-apps/bug_notifier_bot

            qdna_details:
                cluster_ip: 172.21.97.68
                username: admin
                password: Maglev123



Running the Utility --
    - You can run the utility using the following command --
        - "sh run.sh"


Logging information --
    - Tool logs can be found in "chat_bot.log"
    - Log Rotation Policy --
        - Logs will be rotated automatically when log file size goes above 5 MB
        - Last 10 log files will be preserved (last 50 MB logs)



Current pending Development Tasks --
    - Creating an install script to install the tool
    - Creating a run script which runs the tool --
        - Making all necessary changes from the code perspective
        - Also providing handlers to schedule, delete and get status of the cronjob



Future Enhancements --
    - Converting the utility into an NLP AI driven tool wherein it understands user input given in human readable
      format converts it to a valid Jira query (NLP Advancement)
    - Monitoring bugs tagged for a release as they go in “Dev-Complete” state and assign them to respective
      QA folks and sending notification to them in person
    - Changing fields of bug or list of bugs from the chatbot
    - Cluster debugging tool which provides a basic debugging report for a given cluster and sends it to the user



Important Links --
    - https://developer.webex.com/docs/platform-introduction
    - https://developer.webex.com/docs/bots
    - https://jira.readthedocs.io/en/master/
    - https://jira.readthedocs.io/en/master/api.html
    - https://qdna.cisco.com/
    - https://confluence-eng-sjc1.cisco.com/conf/pages/viewpage.action?spaceKey=QDNA&title=QDNA+Dashboard+Service
